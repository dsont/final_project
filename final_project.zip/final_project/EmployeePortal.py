from flask import Flask
from flask import render_template
from flask import url_for
from flask import request
from flask_bootstrap import Bootstrap
import sqlite3 as sql
app= Flask(__name__)
Bootstrap(app)


@app.route("/login")
def emp_login():
    render_template("login.html")
    return render_template("login.html")

@app.route("/emplist")
def list_data():
    con=sql.connect("EmpDatabase.db")
    con.row_factory=sql.Row

    cur=con.cursor()
    cur.execute("SELECT * FROM employee")

    rows=cur.fetchall()
    return render_template("emplist.html", rows = rows)


@app.route("/save/<string:name>/<string:Lastname>/<string:Username>/<string:Password>")
def save_data(name, Lastname, Username, Password):
    with sql.connect("EmpDatabase.db") as con:
        cur=con.cursor()
        cur.execute("INSERT INTO employee (name, Lastname, Username, Password) VALUES (?, ?, ?, ?)", [name, Lastname, Username, Password])
    con.commit()

    return "Record Successfully added {0} {1}".format(name, Lastname)



@app.route("/addrec" , methods=["POST", 'GET'])
def addrec():
    if request.method=="POST":
        name=request.form["name"]
        Lastname=request.form["Lastname"]
        Username=request.form["Username"]
        Password=request.form["Password"]
        with sql.connect("EmpDatabase.db") as con:
            cur=con.cursor()
            cur.execute("INSERT INTO employee (name, Lastname, Username, Password) VALUES (?, ?, ?, ?)", [name,Lastname,Username,Password])
            con.commit()

            return render_template("emplist.html")
#def create_database():
 #   conn = sql.connect("EmpDatabase.db")
  #  conn.execute("CREATE TABLE employee (name TEXT, Lastname TEXT, Username TEXT, Password TEXT)")
   # conn.close()

#create_database()

if __name__=='__main__':
    app.run(debug=True)